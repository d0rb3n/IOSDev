////Problem 1
//for number in 1...100{ //loop to get each number
//    if number % 3 == 0 && number % 5 == 0{ //check if divisable by 3 and 5
//        print("FizzBuzz")
//    }
//    else if number % 3 == 0{ //check if divisable by 3
//        print("Fizz")
//    }
//    else if number % 5 == 0{ //check if divisable by 5
//        print("Buzz")
//    }
//    else{
//        print(number) //just print number if it not fits conditionals
//    }
//}

////Problem 2
//func isPrime(_ number: Int) -> Bool{
//    if number < 2{ //1 and 0 are not primes
//        return false
//    }
//    for i in 2...max(2, Int(Double(number).squareRoot())){ //with max we guarantee for upperbound is not less than 2, our squareroot will not be less than 2
//        if number % i == 0{
//            return false
//        }
//    }
//    return true
//}
//for num in 1...100{ //loop to print prime numbers using function
//    if isPrime(num){
//        print(num)
//    }
//}

////Problem 3
//import Foundation
//func celciusToFarenheit(_ celcius: Double) -> Double { //func to calculate farenheit from celcius
//    return (celcius * 9/5) + 32
//}
//func celciusToKelvin(_ celcius: Double)-> Double{//func to calculate kelvin from celcius
//    return celcius + 273.15
//}
//func farenheitToCelcius(_ farenheit: Double) -> Double{//func to calculate celcius from farenheit
//    return (farenheit - 32) * 5/9
//}
//func farenheitToKelvin(_ farenheit: Double)-> Double{//func to calculate kelvin from farenheit
//    return (farenheit - 32) * 5/9 + 273.15
//}
//func kelvinToCelcius(_ kelvin: Double)-> Double{//func to calculate celcius from kelvin
//    return kelvin - 273.15
//}
//func kelvinToFarenheit(_ kelvin: Double) -> Double{//func to calculate farenheit from kelvin
//    return (kelvin - 273.15) * 9/5 + 32
//}
//
//let examples: [(Double, String)] = [
//    (25, "C"),
//    (77, "F"),
//    (300, "K")
//]
//
//for (temperature, unit) in examples {
//    print("\nInput: \(temperature) \(unit)")
//    
//    if unit.uppercased() == "C"{//check for temp type and call functions
//        let farenheit = celciusToFarenheit(temperature)
//        let kelvin = celciusToKelvin(temperature)
//        print("\(temperature) degree C is equal to \(farenheit) degree F and \(kelvin) degree K")
//    }
//    else if unit.uppercased() == "F"{//check for temp type and call functions
//        let celcius = farenheitToCelcius(temperature)
//        let kelvin = farenheitToKelvin(temperature)
//        print("\(temperature) degree F is equal to \(celcius) degree C and \(kelvin) degree K")
//    }
//    else if unit.uppercased() == "K"{//check for temp type and call functions
//        let celcius = kelvinToCelcius(temperature)
//        let farenheit = kelvinToFarenheit(temperature)
//        print("\(temperature) degree K is equal to \(celcius) degree C and \(farenheit) degree F")
//    }
//    else{
//        print("Invalid input")
//    }
//}


//Problem 4
//import Foundation
//
//var shoppingList: [String] = [] //creating empty list
//var isRunning = true //for working cycle
//
//while isRunning {
//    print("""
//    \n Shopping List Manager
//    1. Add item
//    2. Remove item
//    3. View shopping list
//    4. Exit
//    Enter your choice:
//    """)
//    
//    if let choice = readLine() {
//        switch choice {
//        case "1":
//            print("Enter item to add:")
//            if let item = readLine(), !item.isEmpty { //returns line and string is not empty
//                shoppingList.append(item) //adding item in the list
//                print("'\(item)' added to the list.")
//            } else {
//                print("Item cannot be empty.")
//            }
//            
//        case "2":
//            print("Enter item to remove:")
//            if let item = readLine() {
//                if let index = shoppingList.firstIndex(of: item) { //checking if there is element item if yes returns index if not -> nil
//                    shoppingList.remove(at: index)
//                    print("'\(item)' removed from the list.")
//                } else {
//                    print("Item not found in the list.")
//                }
//            }
//            
//        case "3":
//            if shoppingList.isEmpty {
//                print("Your shopping list is empty.")
//            } else {
//                print("Shopping List:")
//                for (index, item) in shoppingList.enumerated() { //returning array element item and its index
//                    print("\(index + 1). \(item)") //to start from 1 and not 0
//                }
//            }
//            
//        case "4":
//            print("Exiting Shopping List Manager. Goodbye!") //exit from list application
//            isRunning = false //cycle ends
//
//        default:
//            print("Invalid choice. Please enter 1–4.")
//        }
//    }
//}

////Problem 5
//import Foundation
//let input = "Hello, hello! Swift is great. Swift, Swift, Swift!!!"
//print("Sentence: \(input)")
//let lowercased = input.lowercased() // put string in lowercase
//let cleaned = lowercased.components(separatedBy: CharacterSet.punctuationCharacters).joined() // separating for only letters without punctuation marks and join
//let words = cleaned.split(separator: " ").map {String($0)} // spliting string for array and turning substring to string with map
//
//var wordFrequency: [String: Int] = [:]
//for word in words{
//    if wordFrequency[word] != nil{
//        wordFrequency[word]! += 1 // increasing number of repeated words
//    }
//    else{
//        wordFrequency[word] = 1
//    }
//}
//
//print("\nWord frequencies:")
//for (word, count) in wordFrequency{
//    print("\(word): \(count)")
//}

////Problem 6
//func fibonacci(_ n: Int) -> [Int]{
//    if n <= 0{ //if n <= 0 empty array
//        return[]
//    }
//    if n == 1{ //if n = 1 only output 0
//        return[0]
//    }
//    var sequence: [Int] = [0,1] //start from first two digits
//    for _ in 2..<n{ //loop for constructing a sequence
//        let nextNumber = sequence.last! + sequence[sequence.count-2]
//        sequence.append(nextNumber)
//    }
//    return sequence
//}
//print(fibonacci(10))

////Problem 7
//import Foundation
//
//let students: [String: Int] = [
//    "Alice": 85,
//    "Bob": 92,
//    "Charlie": 67,
//    "Diana": 74,
//    "Ethan": 58
//]
//let scores = Array(students.values) //extracting all scores
//let average = Double(scores.reduce(0, +)) / Double(scores.count) //calculating average
//if let highest = scores.max(), let lowest = scores.min() { //extracting min and max score
//    print("Grade Report")
//    print("Average score: \(String(format: "%.2f", average))")
//    print("Highest score: \(highest)")
//    print("Lowest score: \(lowest)\n")
//    
//    for (name, score) in students { //output for each student
//        if Double(score) >= average {
//            print("\(name): \(score) Above average")
//        } else {
//            print("\(name): \(score) Below average")
//        }
//    }
//}

////Problem 8
//import Foundation
//func isPalindrome(_ text: String) -> Bool{
//    let lowercased = text.lowercased() //making all leters lowercase
//    let cleaned = lowercased.filter{$0.isLetter || $0.isNumber} //removing all symbols except letters and numbers
//    return cleaned == String(cleaned.reversed()) //compare regular string and it's reverse
//}
//print(isPalindrome("Racecar"))
//print(isPalindrome("Hello"))

////Problem 9
//import Foundation
//
//func add(_ a: Double, _ b: Double) -> Double{
//    return a+b
//}
//func subtract(_ a: Double, _ b:Double) -> Double{
//    return a - b
//}
//func multiply(_ a:Double, _ b:Double) -> Double{
//    return a * b
//}
//func divide(_ a:Double, _ b:Double) -> Double?{// division function (nil if division by zero)
//    if b == 0{
//        return nil
//    }
//    return a / b
//}
//
//let num1 = 12.0
//let num2 = 4.0
//let operation = "+"
//
//print("First number: \(num1)")
//print("Second number: \(num2)")
//print("Operation: \(operation)")
//
//var result: Double? // ? because it can be no result
//
//switch operation{
//case "+":
//    result = add(num1, num2)
//case "-":
//    result = subtract(num1, num2)
//case "*":
//    result = multiply(num1, num2)
//case "/":
//    if let res = divide(num1, num2){
//        result = res
//    }
//    else{
//        print("Cannot divide by zero!")
//    }
//default:
//    print("Invalid operation")
//}
//
//if let res = result{ // if not nil we save in res and output it
//    print("Result: \(res)")
//}

////Problem 10
//func hasUniqueCharacter(_ text: String) -> Bool{
//    let uniqueChars = Set(text) //set keep only unique elememts
//    return uniqueChars.count == text.count //if amount of unique simbols match with string length -> all symbols unique
//}
//print(hasUniqueCharacter("swift"))
//print(hasUniqueCharacter("Arman"))
//print(hasUniqueCharacter("hello"))
