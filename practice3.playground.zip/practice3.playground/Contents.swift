import Foundation
struct Product{
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String
    
    enum Category{ //adding enum
        case clothing
        case electronics
        case books
        case food
    }
    var displayPrice: String{
        return String(format: "%.2f", price) //price format
    }
    init?(id:String, name:String, price:Double, category:Category, description:String){
        guard price > 0 else {return nil} //ensuring that price is positive if not returning nil
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}

struct CartItem{
    let product: Product
    private(set) var quantity: Int
    
    var subtotal: Double{
        return product.price * Double(quantity) //calculate: product.price * quantity
    }
    mutating func updateQuantity(_ newQuantity: Int){
        guard newQuantity > 0 else {return} //validate newQuantity > 0
        self.quantity = newQuantity //update quantity
    }
    mutating func increaseQuantity(by amount: Int){
        guard amount > 0 else {return}
        self.quantity += amount //adding to existing quantity
    }
    init?(product: Product, quantity: Int){
        guard quantity > 0 else {return nil}
        self.product = product
        self.quantity = quantity
    }
}

class ShoppingCart{
    private(set) var items: [CartItem] = []
    var discountCode: String? //optional discount
    init(){ //initializer
        self.items = []
    }
    func addItem(product: Product, quantity: Int = 1){ //add item to cart
        guard quantity > 0 else {return}
        if let index = items.firstIndex(where: {$0.product.id == product.id}){ //check if we have this item
            var existingItem = items[index]
            existingItem.increaseQuantity(by: quantity)//if exists increase quantity
            items[index] = existingItem
        }
        else{
            if let newItem = CartItem(product: product, quantity: quantity){ //if not creating new item
                items.append(newItem)
            }
        }
    }
    func removeItem(productId: String){
        items.removeAll {$0.product.id == productId} //delete item using ID
    }
    func updateItemQuantity(productId: String, quantity: Int){
        guard let index = items.firstIndex(where:{ $0.product.id == productId}) else{return}
        if quantity == 0 {
            removeItem(productId: productId) // if item quantity = 0 -> delete
        }
        else{
            var item = items[index]
            item.updateQuantity(quantity)
            items[index] = item
        }
    }
    func clearCart(){
        items.removeAll() //clearing cart
    }
    var subtotal: Double{
        items.reduce(0) {$0 + $1.subtotal } //total without discount
    }
    var discountAmount: Double {
        guard let code = discountCode else { return 0 } //discount amount
        switch code {
        case "SAVE10": return subtotal * 0.10
        case "SAVE20": return subtotal * 0.20
        default: return 0
        }
    }
    var total: Double{ //total price
        subtotal - discountAmount
    }
    var itemCount:Int{
        items.reduce(0) {$0 + $1.quantity} //total amount of items
    }
    var isEmpty:Bool{ //check if cart is empty
        items.isEmpty
    }
}

struct Address {
    let street: String
    let city: String
    let zipCode: String
    let country: String
    
    var formattedAddress: String {
        return "\(street)\n\(city), \(zipCode)\n\(country)"
    }
}

struct Order { //properties
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address
    
    var itemCount: Int { //computed property
        items.reduce(0) { $0 + $1.quantity }
    }
    
    init(from cart: ShoppingCart, shippingAddress: Address) { //initializer
        self.orderId = UUID().uuidString
        self.items = cart.items    //coping items from cart
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }
}
