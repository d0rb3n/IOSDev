import Foundation
class ShoppingCart{
    private(set) var items: [CartItem] = []
    var discountCode: String? //optional discount
    init(){ //initializer
        self.items = []
    }
    func addItem(product: Product, quantity: Int = 1){ //add item to cart
        guard quantity > 0 else {return}
        if let index = items.firstIndex(where: {$0.product.id == product.id}){ //check if we have this item
            var existingItem = items[index]
            existingItem.increaseQuantity(by: quantity)//if exists increase quantity
            items[index] = existingItem
        }
        else{
            if let newItem = CartItem(product: product, quantity: quantity){ //if not creating new item
                items.append(newItem)
            }
        }
    }
    func removeItem(productId: String){
        items.removeAll {$0.product.id == productId} //delete item using ID
    }
    func updateItemQuantity(productId: String, quantity: Int){
        guard let index = items.firstIndex(where:{ $0.product.id == productId}) else{return}
        if quantity == 0 {
            removeItem(productId: productId) // if item quantity = 0 -> delete
        }
        else{
            var item = items[index]
            item.updateQuantity(quantity)
            items[index] = item
        }
    }
    func clearCart(){
        items.removeAll() //clearing cart
    }
    var subtotal: Double{
        items.reduce(0) {$0 + $1.subtotal } //total without discount
    }
    var discountAmount: Double {
        guard let code = discountCode else { return 0 } //discount amount
        switch code {
        case "SAVE10": return subtotal * 0.10
        case "SAVE20": return subtotal * 0.20
        default: return 0
        }
    }
    var total: Double{ //total price
        subtotal - discountAmount
    }
    var itemCount:Int{
        items.reduce(0) {$0 + $1.quantity} //total amount of items
    }
    var isEmpty:Bool{ //check if cart is empty
        items.isEmpty
    }
}
