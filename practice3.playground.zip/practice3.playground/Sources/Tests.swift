import Foundation

func runTests() {
    print("=== Shopping Cart System Tests ===\n")
    
    // 1. Create sample products
    guard let laptop = Product(id: "p1", name: "MacBook Pro", price: 1999.99, category: .electronics, description: "Apple laptop"),
          let book = Product(id: "p2", name: "Swift Programming", price: 39.99, category: .books, description: "Learn Swift"),
          let headphones = Product(id: "p3", name: "AirPods", price: 199.99, category: .electronics, description: "Wireless earbuds")
    else {
        print("Failed to create products")
        return
    }
    
    // 2. Add items to cart
    let cart = ShoppingCart()
    cart.addItem(product: laptop, quantity: 1)
    cart.addItem(product: book, quantity: 2)
    
    print("Subtotal:", cart.subtotal)
    print("Item count:", cart.itemCount)
    
    // 3. Add same product again
    cart.addItem(product: laptop, quantity: 1)
    print("Laptop quantity updated → Subtotal:", cart.subtotal)
    
    // 4. Apply discount
    cart.discountCode = "SAVE10"
    print("Total with discount:", cart.total)
    
    // 5. Remove item
    cart.removeItem(productId: book.id)
    print("Book removed → Subtotal:", cart.subtotal)
    
    // 6. Test reference type
    func modifyCart(_ cart: ShoppingCart) {
        cart.addItem(product: headphones, quantity: 1)
    }
    modifyCart(cart)
    print("After modifyCart() → contains AirPods:", cart.itemCount)
    
    // 7. Value type test
    let item1 = CartItem(product: laptop, quantity: 1)!
    var item2 = item1
    item2.updateQuantity(5)
    print("Item1.quantity:", item1.quantity)
    print("Item2.quantity:", item2.quantity)
    
    // 8. Create order
    let address = Address(street: "123 Main St", city: "San Francisco", zipCode: "94105", country: "USA")
    let order = Order(from: cart, shippingAddress: address)
    
    print("Order created → ID:", order.orderId)
    print("Order total:", order.total)
    print("Ship to:\n\(order.shippingAddress.formattedAddress)")
    
    // 9. Clear cart and verify immutability
    cart.clearCart()
    print("Cart cleared → itemCount:", cart.itemCount)
    print("Order still has:", order.itemCount, "items\n")
    
    print("=== All Tests Passed ✅ ===")
}
