
# 🛒 Shopping Cart System

## Overview
This project implements a simple Shopping Cart System in Swift to demonstrate the differences between **classes (reference types)** and **structs (value types)**.
It includes product and cart item models, a shopping cart manager, order creation, and address handling.
The focus of this assignment was to understand **value semantics vs. reference semantics**, encapsulation, mutability, and proper use of `struct` and `class` in Swift.

---

## 🧩 Why I Chose `class` for `ShoppingCart`
The `ShoppingCart` type was implemented as a **class** because a cart represents a single shared instance that should be **mutable and passed by reference**.
If a user adds or removes items from their cart, these changes should be reflected everywhere that cart instance is used.
For example, if we pass the cart object into a function that modifies it, we expect the original cart to be updated — not a copy.

Using a `class` allows us to maintain **a single shared identity** for the cart across the app.
This behavior aligns with the real-world concept of a shopping cart: there is one cart per user, and any modification to it should persist.

---

## 📦 Why I Chose `struct` for `Product` and `Order`
`Product` and `Order` were implemented as **structs** because they are **data models** that do not require identity — they represent immutable snapshots of data.

- A `Product` is just a set of information (id, name, price, category). Copying or comparing products does not need reference behavior.
- An `Order` represents a finalized snapshot of a shopping cart at the moment of checkout. After creation, it should not be mutable.

By using structs, each product or order remains independent. Changing one does not affect another.
This demonstrates **value semantics**, which improves safety and predictability in data handling.

---

## 🔁 Example Where Reference Semantics Matter
In the `ShoppingCart` class, reference semantics are essential.
For example:
```swift
func modifyCart(_ cart: ShoppingCart) {
    cart.addItem(product: headphones, quantity: 1)
}
modifyCart(cart)
