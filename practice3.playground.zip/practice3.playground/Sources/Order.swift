import Foundation
struct Order { //properties
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address
    
    var itemCount: Int { //computed property
        items.reduce(0) { $0 + $1.quantity }
    }
    
    init(from cart: ShoppingCart, shippingAddress: Address) { //initializer
        self.orderId = UUID().uuidString
        self.items = cart.items    //coping items from cart
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }
}
