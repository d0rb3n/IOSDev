import Foundation
struct Product{
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String
    
    enum Category{ //adding enum
        case clothing
        case electronics
        case books
        case food
    }
    var displayPrice: String{
        return String(format: "%.2f", price) //price format
    }
    init?(id:String, name:String, price:Double, category:Category, description:String){
        guard price > 0 else {return nil} //ensuring that price is positive if not returning nil
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}
