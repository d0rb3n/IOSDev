import Foundation
struct CartItem{
    let product: Product
    private(set) var quantity: Int
    
    var subtotal: Double{
        return product.price * Double(quantity) //calculate: product.price * quantity
    }
    mutating func updateQuantity(_ newQuantity: Int){
        guard newQuantity > 0 else {return} //validate newQuantity > 0
        self.quantity = newQuantity //update quantity
    }
    mutating func increaseQuantity(by amount: Int){
        guard amount > 0 else {return}
        self.quantity += amount //adding to existing quantity
    }
    init?(product: Product, quantity: Int){
        guard quantity > 0 else {return nil}
        self.product = product
        self.quantity = quantity
    }
}
