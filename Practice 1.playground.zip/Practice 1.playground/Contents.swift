import UIKit

//Step 1
let firstName = "Darkhan"
let lastName = "Makhmutov"
var age: Int = 20
let birthYear: Int = 2005
var isStudent: Bool = true
var height: Double = 1.80
var weight: Double = 63.5
var country: String = "Kazakhstan"
var city: String = "Almaty"

//Bonus
let currentYear: Int = 2025
let calcAge: Int = currentYear - birthYear

//Step 2
var hobby: String = "Video Games"
var numberOfHobbies: Int = 3
var favouriteNum: Int = 66
var isHobbyCreative: Bool = false
var favMusicGenre: String = "Rap"
var favFood: String = "Pasta"
var favMovie: String = "John Wick"

//Step 3
let lifeStory: String = "My name is \(firstName) \(lastName). I am \(age) years old. I was born in \(birthYear) in \(country), \(city). Currently I am a student. I like \(hobby), my favourite number is \(favouriteNum), my favourite music genre is \(favMusicGenre), I like \(favFood), and my favourite movie is \(favMovie)."

//Step 4
print(lifeStory)

//Bonus
var futureGoals: String = "In the future I want to become a successful developer 💻, become a good father 👨 and have a great life in general☀️"
print(lifeStory + futureGoals)

